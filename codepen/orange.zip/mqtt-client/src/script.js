  // Сначала код для подключения к MQTT-брокеру. Свой код раньше не пишем!

  client = new Paho.MQTT.Client("m24.cloudmqtt.com", 30372,"orange-site");
  
  // назначение обработчиков для принятия сообщений и обрыва связи
  client.onConnectionLost = onConnectionLost;
  client.onMessageArrived = onMessageArrived;

    // параметры для связи с брокером
  var options = {
    useSSL: true,
    userName: "dcgbvrdp",
    password: "laxu4wz8J9fM",
    onSuccess:onConnect,
    onFailure:doFail
  }

  
  var btn = document.querySelector('#btn');
  var mqttMess = document.querySelector('#mqttMess');
  var getTemp = document.querySelector('#getTemp');
  var getTempContinious = document.querySelector('#getTempContinious');
  
  // connect по клику
  btn.addEventListener("click", () => {
    mqttMess.innerHTML="MQTT-сообщения: "; client.connect(options)  } );
  
  // получить температуру один раз 
  getTemp.addEventListener("click", () => Send('/temp/get','request'));

  // или с интервалом 2 секунды
  var Continious = true
  var R
  function Run() {
  R = setInterval("Send('/temp/get','request')", 2000)
  }

  getTempContinious.addEventListener("click", () => {
    if (Continious==true) Run()
    else clearInterval(R)
    Continious = !Continious;
  }  )

  // открыть и закрыть форточку. Серву можно крутить от 0.05 до 0.95 с точностью до сотых.
  var doorState = "0.05";
  door.addEventListener("click", () => {
  doorState = doorState == "0.05" ? "0.95" : "0.05";  // тернарный оператор вместо if-else
    Send('/door/turn',doorState)
  }    );

// включить питание реле с кулером 
 var pushRelay = document.querySelector('#pushRelay');
  pushRelay.addEventListener("click", () => Send('/relay/turn','turn request'));

  // когда связь установлена, подписываемся на темы и посылаем тестовое сообщение.
  function onConnect() {
    client.subscribe("/orange");
    client.subscribe("/door");
    client.subscribe("/temp");
    Send("/orange", "Клиент (сайт) подключился к брокеру MQTT-сообщений");
  }

  // обработчики ошибок подключения
  function doFail(e){
    console.log(e);
  }
  function onConnectionLost(responseObject) {
    if (responseObject.errorCode !== 0) {
      console.log("onConnectionLost:"+responseObject.errorMessage);
    }
  }

  // Получение сообщения (обратите внимание как разделены тема и само сообщения.)
  function onMessageArrived(message) {
    /// общий вывод в журнал
    mqttMess.innerHTML += `\<br>`+message.destinationName + '  ' + message.payloadString;
    switch (message.destinationName) {
      case "/temp":
        /// пришла температура
        console.log('пришла темп')
        break;
      case "/door":
        /// пришел сервопривод
        break;
      case "/relay":
        /// пришло реле
        break;
    }
  }

 // Определение функции отправки сообщений в строковом формате. К нам вернутся только по теме, на которую подписаны.
function Send(topic,body) {
    message = new Paho.MQTT.Message(body);
    message.destinationName = topic;
    client.send(message);
}